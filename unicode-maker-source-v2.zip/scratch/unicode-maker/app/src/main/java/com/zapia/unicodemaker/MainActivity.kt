package com.zapia.unicodemaker

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowDownward
import androidx.compose.material.icons.filled.ArrowForward
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.ArrowUpward
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val Ink = Color(0xFF10111A)
private val Panel = Color(0xFF1B1D2A)
private val Purple = Color(0xFF8B80F9)
private val White = Color(0xFFF5F4FF)
private val Muted = Color(0xFFB8B6C8)
private val Blocks = listOf("█", "▓", "▒", "░", "▀", "▄", "▌", "▐", "■", "□", "◆", "◇", "●", "○", "▲", "△", "╱", "╲", "─", "│", "┌", "┐", "└", "┘", "┼", "★", "☆", "♥", "♡", "Espacio")
private data class Cell(val x: Int, val y: Int, val value: String)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { MakerScreen() }
    }
}

@Composable
private fun MakerScreen() {
    val context = LocalContext.current
    val cells = remember { mutableStateListOf<Cell>() }
    var cursorX by remember { mutableIntStateOf(0) }
    var cursorY by remember { mutableIntStateOf(0) }
    var selectedBlock by remember { mutableStateOf("█") }
    var selectedCell by remember { mutableStateOf<Pair<Int, Int>?>(null) }
    var gap by remember { mutableIntStateOf(1) }
    var status by remember { mutableStateOf("Elige un bloque y colócalo con las flechas.") }

    val width = maxOf(5, (cells.maxOfOrNull { it.x } ?: 0) + 1, cursorX + 1)
    val height = maxOf(4, (cells.maxOfOrNull { it.y } ?: 0) + 1, cursorY + 1)
    val output = buildString {
        for (y in 0..(cells.maxOfOrNull { it.y } ?: -1)) {
            if (y > 0) append("\n".repeat(gap.coerceAtLeast(1)))
            val maxX = cells.filter { it.y == y }.maxOfOrNull { it.x } ?: -1
            for (x in 0..maxX) {
                val v = cells.firstOrNull { it.x == x && it.y == y }?.value
                append(v ?: " ")
                if (gap > 1 && x < maxX) append(" ".repeat(gap - 1))
            }
        }
    }

    MaterialTheme(colorScheme = darkColorScheme(primary = Purple, onPrimary = Ink, background = Ink, surface = Panel, onSurface = White, secondary = Color(0xFFB4AFFF))) {
        Column(Modifier.fillMaxSize().background(Ink).verticalScroll(rememberScrollState()).padding(horizontal = 18.dp, vertical = 14.dp)) {
            Text("Unicode Maker", color = White, fontSize = 28.sp, fontWeight = FontWeight.Bold)
            Text("Desde un bloque. Hasta un proyecto.", color = Muted, fontSize = 14.sp, modifier = Modifier.padding(top = 3.dp, bottom = 14.dp))

            Text("VISTA PREVIA", color = Muted, fontSize = 12.sp, fontWeight = FontWeight.Bold)
            Surface(color = Panel, shape = RoundedCornerShape(18.dp), border = BorderStroke(1.dp, Purple.copy(alpha = .45f)), modifier = Modifier.fillMaxWidth().padding(top = 8.dp)) {
                Column(Modifier.padding(14.dp)) {
                    Text("Toca una pieza para seleccionarla y moverla.", color = Muted, fontSize = 12.sp)
                    Spacer(Modifier.height(10.dp))
                    Column(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState())) {
                        for (y in 0 until height) {
                            Row {
                                for (x in 0 until width) {
                                    val cell = cells.firstOrNull { it.x == x && it.y == y }
                                    val isCursor = if (selectedCell != null) selectedCell == (x to y) else cursorX == x && cursorY == y
                                    val label = when {
                                        cell != null -> "Fila ${y + 1}, columna ${x + 1}: bloque ${cell.value}"
                                        isCursor -> "Posición vacía seleccionada, fila ${y + 1}, columna ${x + 1}"
                                        else -> "Posición vacía, fila ${y + 1}, columna ${x + 1}"
                                    }
                                    Box(Modifier.padding(2.dp).size(42.dp).border(if (isCursor) 2.dp else 1.dp, if (isCursor) Purple else Color(0xFF424456), RoundedCornerShape(8.dp)).background(Color(0xFF141520), RoundedCornerShape(8.dp)).clickable(role = Role.Button) {
                                        if (cell != null) { selectedCell = x to y; cursorX = x; cursorY = y; status = "Bloque ${cell.value} seleccionado." }
                                        else { selectedCell = null; cursorX = x; cursorY = y; status = "Posición ${x + 1}, ${y + 1} seleccionada." }
                                    }.semantics { contentDescription = label }, contentAlignment = Alignment.Center) {
                                        Text(if (cell != null && cell.value.isBlank()) "␣" else cell?.value ?: if (isCursor) "＋" else "·", color = if (isCursor) Purple else if (cell != null) White else Color(0xFF56576A), fontSize = if (cell == null) 16.sp else 21.sp, fontWeight = FontWeight.SemiBold)
                                    }
                                }
                            }
                        }
                    }
                    Text(status, color = Muted, fontSize = 12.sp, modifier = Modifier.padding(top = 8.dp))
                }
            }

            Text("MOVER O COLOCAR", color = Muted, fontSize = 12.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(top = 18.dp, bottom = 8.dp))
            Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.fillMaxWidth()) {
                ArrowControl("Arriba", Icons.Default.ArrowUpward) {
                    if (selectedCell != null) moveCell(cells, selectedCell!!, 0, -1)?.let { selectedCell = it; cursorX = it.first; cursorY = it.second } else cursorY = (cursorY - 1).coerceAtLeast(0)
                }
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    ArrowControl("Izquierda", Icons.Default.ArrowBack) {
                        if (selectedCell != null) moveCell(cells, selectedCell!!, -1, 0)?.let { selectedCell = it; cursorX = it.first; cursorY = it.second } else cursorX = (cursorX - 1).coerceAtLeast(0)
                    }
                    FilledTonalButton(onClick = {
                        if (selectedCell != null) {
                            cells.removeAll { it.x == selectedCell!!.first && it.y == selectedCell!!.second }
                            selectedCell = null
                            status = "Bloque quitado del diseño."
                        } else {
                            val prev = cells.firstOrNull { it.x == cursorX && it.y == cursorY }
                            if (prev != null) cells.remove(prev)
                            val value = if (selectedBlock == "Espacio") " " else selectedBlock
                            cells.add(Cell(cursorX, cursorY, value)); selectedCell = cursorX to cursorY
                            status = if (selectedBlock == "Espacio") "Espacio colocado. Puedes moverlo con las flechas; se copiará como un hueco." else "Bloque $selectedBlock colocado. Usa las flechas para moverlo."
                        }
                    }, colors = ButtonDefaults.filledTonalButtonColors(containerColor = Purple, contentColor = Ink), modifier = Modifier.height(48.dp)) { Text(if (selectedCell != null) "Quitar" else if (selectedBlock == "Espacio") "Espacio" else "Colocar", fontWeight = FontWeight.Bold) }
                    ArrowControl("Derecha", Icons.Default.ArrowForward) {
                        if (selectedCell != null) moveCell(cells, selectedCell!!, 1, 0)?.let { selectedCell = it; cursorX = it.first; cursorY = it.second } else cursorX = (cursorX + 1).coerceAtMost(29)
                    }
                }
                ArrowControl("Abajo", Icons.Default.ArrowDownward) {
                    if (selectedCell != null) moveCell(cells, selectedCell!!, 0, 1)?.let { selectedCell = it; cursorX = it.first; cursorY = it.second } else cursorY = (cursorY + 1).coerceAtMost(19)
                }
            }
            Text("Con un bloque seleccionado, las flechas lo mueven. Sin bloque, mueven la posición de inserción.", color = Muted, fontSize = 12.sp, textAlign = TextAlign.Center, modifier = Modifier.fillMaxWidth().padding(top = 4.dp))

            Text("BLOQUES UNICODE", color = Muted, fontSize = 12.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(top = 18.dp, bottom = 8.dp))
            Surface(color = Panel, shape = RoundedCornerShape(16.dp), modifier = Modifier.fillMaxWidth()) {
                Column(Modifier.padding(12.dp)) {
                    Text("Selecciona una pieza visual; luego pulsa Colocar.", color = Muted, fontSize = 12.sp)
                    Spacer(Modifier.height(8.dp))
                    val grid = Blocks.chunked(6)
                    grid.forEach { row ->
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            row.forEach { block ->
                                val isSpace = block == "Espacio"
                                Box(Modifier.weight(1f).padding(vertical = 3.dp).height(46.dp).semantics { role = Role.Button }.border(if (selectedBlock == block) 2.dp else 1.dp, if (selectedBlock == block) Purple else Color(0xFF48495A), RoundedCornerShape(10.dp)).background(if (selectedBlock == block) Purple.copy(alpha = .18f) else Color(0xFF242635), RoundedCornerShape(10.dp)).clickable { selectedBlock = block; selectedCell = null; status = if (isSpace) "Espacio seleccionado: al colocarlo deja un hueco." else "Bloque $block seleccionado." }.semantics { contentDescription = if (isSpace) "Seleccionar espacio" else "Seleccionar bloque $block" }, contentAlignment = Alignment.Center) {
                                    Text(if (isSpace) "␣" else block, color = White, fontSize = if (isSpace) 13.sp else 22.sp, fontWeight = FontWeight.Bold)
                                }
                            }
                            repeat(6 - row.size) { Spacer(Modifier.weight(1f)) }
                        }
                    }
                }
            }

            Text("SEPARACIÓN", color = Muted, fontSize = 12.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(top = 18.dp, bottom = 4.dp))
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("Cerca", color = Muted, fontSize = 13.sp)
                Slider(value = gap.toFloat(), onValueChange = { gap = it.toInt().coerceIn(1, 4) }, valueRange = 1f..4f, steps = 2, modifier = Modifier.weight(1f).semantics { contentDescription = "Separación entre bloques, nivel $gap" })
                Text("$gap", color = White, fontWeight = FontWeight.Bold)
                Text("Lejos", color = Muted, fontSize = 13.sp)
            }

            Row(Modifier.fillMaxWidth().padding(top = 12.dp, bottom = 22.dp), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                OutlinedButton(onClick = {
                    cells.clear(); cursorX = 0; cursorY = 0; selectedCell = null; status = "Lienzo vacío. Elige un bloque para empezar."
                }, modifier = Modifier.weight(1f).height(52.dp), border = BorderStroke(1.dp, Color(0xFF77788A))) {
                    Icon(Icons.Default.Delete, contentDescription = null); Spacer(Modifier.width(6.dp)); Text("Limpiar", color = White)
                }
                Button(onClick = {
                    if (output.isBlank()) Toast.makeText(context, "Coloca algún bloque primero", Toast.LENGTH_SHORT).show()
                    else {
                        val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                        clipboard.setPrimaryClip(ClipData.newPlainText("Unicode Maker", output))
                        Toast.makeText(context, "Unicode copiado. Ya puedes pegarlo en otra app.", Toast.LENGTH_LONG).show()
                    }
                }, modifier = Modifier.weight(1.25f).height(52.dp), colors = ButtonDefaults.buttonColors(containerColor = Purple, contentColor = Ink)) {
                    Icon(Icons.Default.ContentCopy, contentDescription = null); Spacer(Modifier.width(7.dp)); Text("Copiar todo", fontWeight = FontWeight.Bold)
                }
            }
        }
    }
}

@Composable
private fun ArrowControl(label: String, icon: androidx.compose.ui.graphics.vector.ImageVector, onClick: () -> Unit) {
    FilledTonalButton(onClick = onClick, modifier = Modifier.size(52.dp).semantics { contentDescription = label }, shape = RoundedCornerShape(14.dp), contentPadding = PaddingValues(0.dp), colors = ButtonDefaults.filledTonalButtonColors(containerColor = Color(0xFF292B3A), contentColor = White)) {
        Icon(icon, contentDescription = null, modifier = Modifier.size(25.dp))
    }
}

private fun moveCell(cells: MutableList<Cell>, from: Pair<Int, Int>, dx: Int, dy: Int): Pair<Int, Int>? {
    val nx = (from.first + dx).coerceIn(0, 29)
    val ny = (from.second + dy).coerceIn(0, 19)
    if (nx == from.first && ny == from.second) return from
    val i = cells.indexOfFirst { it.x == from.first && it.y == from.second }
    if (i < 0) return null
    val occupant = cells.indexOfFirst { it.x == nx && it.y == ny }
    val old = cells[i]
    if (occupant >= 0) {
        val other = cells[occupant]
        cells[occupant] = other.copy(x = old.x, y = old.y)
    }
    cells[i] = old.copy(x = nx, y = ny)
    return nx to ny
}
