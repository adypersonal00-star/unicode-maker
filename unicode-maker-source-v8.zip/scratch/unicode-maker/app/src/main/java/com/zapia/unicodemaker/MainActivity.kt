package com.zapia.unicodemaker

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowDownward
import androidx.compose.material.icons.filled.ArrowForward
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.ArrowUpward
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.getValue
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val Ink = Color(0xFF10111A)
private val Panel = Color(0xFF1B1D2A)
private val Purple = Color(0xFF8B80F9)
private val White = Color(0xFFF5F4FF)
private val Muted = Color(0xFFB8B6C8)
private val UnicodeBlocks = listOf("█", "▓", "▒", "░", "▀", "▄", "▌", "▐", "■", "□", "◆", "◇", "●", "○", "▲", "△", "╱", "╲", "─", "│", "┌", "┐", "└", "┘", "┼", "★", "☆", "♥", "♡", "Espacio")
private val AsciiBlocks = listOf("#", "*", "+", "-", "|", "/", "\\", "[", "]", "(", ")", "{", "}", "<", ">", "=", ":", ";", "'", "\"", ".", ",", "_", "^", "v", " ")
private data class Cell(val x: Int, val y: Int, val value: String)

private class EditorState {
    val cells = mutableStateListOf<Cell>()
    val cursorX = mutableIntStateOf(0)
    val cursorY = mutableIntStateOf(0)
    val selectedBlock = mutableStateOf("█")
    val selectedCell = mutableStateOf<Pair<Int, Int>?>(null)
    val gap = mutableIntStateOf(1)
    val width = mutableIntStateOf(20)
    val height = mutableIntStateOf(10)
    val status = mutableStateOf("Elige un bloque y colócalo con las flechas.")
}

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { MakerScreen() }
    }
}

@Composable
private fun MakerScreen() {
    var asciiMode by remember { mutableStateOf(false) }
    val unicodeEditor = remember { EditorState() }
    val asciiEditor = remember { EditorState().also { it.selectedBlock.value = "#" } }
    val editor = if (asciiMode) asciiEditor else unicodeEditor
    val cells = editor.cells
    var cursorX by editor.cursorX
    var cursorY by editor.cursorY
    var selectedBlock by editor.selectedBlock
    var selectedCell by editor.selectedCell
    var gap by editor.gap
    var canvasWidth by editor.width
    var canvasHeight by editor.height
    var status by editor.status
    val context = LocalContext.current
    val blocks = if (asciiMode) AsciiBlocks else UnicodeBlocks
    val output = buildString {
        for (y in 0 until canvasHeight) {
            if (y > 0) append("\n".repeat(gap.coerceAtLeast(1)))
            for (x in 0 until canvasWidth) {
                val v = cells.firstOrNull { it.x == x && it.y == y }?.value ?: " "
                append(v)
                if (gap > 1 && x < canvasWidth - 1) append(" ".repeat(gap - 1))
            }
        }
    }

    MaterialTheme(colorScheme = darkColorScheme(primary = Purple, onPrimary = Ink, background = Ink, surface = Panel, onSurface = White, secondary = Color(0xFFB4AFFF))) {
        Column(Modifier.fillMaxSize().background(Ink).verticalScroll(rememberScrollState()).padding(horizontal = 18.dp, vertical = 14.dp)) {
            Text("Unicode Maker", color = White, fontSize = 28.sp, fontWeight = FontWeight.Bold)
            Text("Desde un bloque. Hasta un proyecto.", color = Muted, fontSize = 14.sp, modifier = Modifier.padding(top = 3.dp, bottom = 5.dp))
            Text("VERSIÓN 2 · UNICODE + ASCII", color = Purple, fontSize = 12.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(bottom = 12.dp))

            Row(Modifier.fillMaxWidth().background(Panel, RoundedCornerShape(16.dp)).padding(4.dp), horizontalArrangement = Arrangement.spacedBy(5.dp)) {
                listOf(false to "Unicode", true to "ASCII").forEach { (ascii, title) ->
                    val active = asciiMode == ascii
                    Box(Modifier.weight(1f).height(48.dp).background(if (active) Purple else Color.Transparent, RoundedCornerShape(12.dp)).clickable {
                        asciiMode = ascii
                        status = if (ascii) "Modo ASCII: usa caracteres de texto simples para dibujar." else "Modo Unicode: bloques sólidos, símbolos y herramientas avanzadas."
                    }.semantics { contentDescription = "Pestaña $title${if (active) ", seleccionada" else ""}" }, contentAlignment = Alignment.Center) {
                        Text(title, color = if (active) Ink else White, fontWeight = FontWeight.Bold, fontSize = 16.sp)
                    }
                }
            }
            Text(if (asciiMode) "Dibuja con caracteres ASCII compatibles con texto simple." else "Usa bloques sólidos, líneas, formas y símbolos Unicode.", color = Muted, fontSize = 13.sp, modifier = Modifier.padding(top = 8.dp, bottom = 12.dp))

            Text("EXPANDIR LIENZO", color = Muted, fontSize = 12.sp, fontWeight = FontWeight.Bold)
            Row(Modifier.fillMaxWidth().padding(top = 6.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedButton(onClick = { cells.replaceAll { it.copy(y = it.y + 1) }; cursorY++; selectedCell = selectedCell?.let { it.first to it.second + 1 }; canvasHeight++ }, modifier = Modifier.weight(1f).height(46.dp)) { Text("↑ Añadir arriba", color = White, fontSize = 12.sp) }
                OutlinedButton(onClick = { canvasHeight++ }, modifier = Modifier.weight(1f).height(46.dp)) { Text("↓ Añadir abajo", color = White, fontSize = 12.sp) }
            }
            Row(Modifier.fillMaxWidth().padding(top = 5.dp, bottom = 6.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedButton(onClick = { cells.replaceAll { it.copy(x = it.x + 1) }; cursorX++; selectedCell = selectedCell?.let { it.first + 1 to it.second }; canvasWidth++ }, modifier = Modifier.weight(1f).height(46.dp)) { Text("← Añadir izquierda", color = White, fontSize = 12.sp) }
                OutlinedButton(onClick = { canvasWidth++ }, modifier = Modifier.weight(1f).height(46.dp)) { Text("→ Añadir derecha", color = White, fontSize = 12.sp) }
            }
            Text("Tamaño: ${canvasWidth} columnas × ${canvasHeight} filas", color = Muted, fontSize = 12.sp, modifier = Modifier.padding(bottom = 8.dp))

            Text("VISTA PREVIA", color = Muted, fontSize = 12.sp, fontWeight = FontWeight.Bold)
            Surface(color = Panel, shape = RoundedCornerShape(18.dp), border = BorderStroke(1.dp, Purple.copy(alpha = .45f)), modifier = Modifier.fillMaxWidth().padding(top = 8.dp)) {
                Column(Modifier.padding(14.dp)) {
                    Text("Toca una pieza para seleccionarla y moverla.", color = Muted, fontSize = 12.sp)
                    Spacer(Modifier.height(10.dp))
                    Column(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()).verticalScroll(rememberScrollState())) {
                        for (y in 0 until canvasHeight) {
                            Row {
                                for (x in 0 until canvasWidth) {
                                    val cell = cells.firstOrNull { it.x == x && it.y == y }
                                    val isCursor = if (selectedCell != null) selectedCell == (x to y) else cursorX == x && cursorY == y
                                    val label = when {
                                        cell != null -> "Fila ${y + 1}, columna ${x + 1}: ${if (cell.value.isBlank()) "espacio" else "bloque ${cell.value}"}"
                                        isCursor -> "Posición vacía seleccionada, fila ${y + 1}, columna ${x + 1}"
                                        else -> "Posición vacía, fila ${y + 1}, columna ${x + 1}"
                                    }
                                    Box(Modifier.padding(2.dp).size(42.dp).border(if (isCursor) 2.dp else 1.dp, if (isCursor) Purple else Color(0xFF424456), RoundedCornerShape(8.dp)).background(Color(0xFF141520), RoundedCornerShape(8.dp)).clickable {
                                        if (cell != null) { selectedCell = x to y; cursorX = x; cursorY = y; status = if (cell.value.isBlank()) "Espacio seleccionado." else "Bloque ${cell.value} seleccionado." }
                                        else { selectedCell = null; cursorX = x; cursorY = y; status = "Posición ${x + 1}, ${y + 1} seleccionada." }
                                    }.semantics { contentDescription = label }, contentAlignment = Alignment.Center) {
                                        Text(if (cell != null && cell.value.isBlank()) "␣" else cell?.value ?: if (isCursor) "＋" else "·", color = if (isCursor) Purple else if (cell != null) White else Color(0xFF56576A), fontSize = if (cell == null) 16.sp else 21.sp, fontWeight = FontWeight.SemiBold)
                                    }
                                }
                            }
                        }
                    }
                    Text(status, color = Muted, fontSize = 12.sp, modifier = Modifier.padding(top = 8.dp))
                }
            }

            Text("MOVER O COLOCAR", color = Muted, fontSize = 12.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(top = 18.dp, bottom = 8.dp))
            Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.fillMaxWidth()) {
                ArrowControl("Arriba", Icons.Default.ArrowUpward) { moveOrCursor(cells, selectedCell, cursorX, cursorY, 0, -1, canvasWidth, canvasHeight)?.let { if (selectedCell != null) selectedCell = it else { cursorX = it.first; cursorY = it.second } } }
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    ArrowControl("Izquierda", Icons.Default.ArrowBack) { moveOrCursor(cells, selectedCell, cursorX, cursorY, -1, 0, canvasWidth, canvasHeight)?.let { if (selectedCell != null) selectedCell = it else { cursorX = it.first; cursorY = it.second } } }
                    FilledTonalButton(onClick = {
                        if (selectedCell != null) {
                            cells.removeAll { it.x == selectedCell!!.first && it.y == selectedCell!!.second }; selectedCell = null; status = "Bloque quitado del diseño."
                        } else {
                            val prev = cells.firstOrNull { it.x == cursorX && it.y == cursorY }
                            if (prev != null) cells.remove(prev)
                            val value = if (selectedBlock == "Espacio") " " else selectedBlock
                            cells.add(Cell(cursorX, cursorY, value)); selectedCell = cursorX to cursorY
                            status = if (selectedBlock == "Espacio") "Espacio colocado; puedes moverlo con las flechas." else "Bloque $selectedBlock colocado. Usa las flechas para moverlo."
                        }
                    }, colors = ButtonDefaults.filledTonalButtonColors(containerColor = Purple, contentColor = Ink), modifier = Modifier.height(48.dp)) { Text(if (selectedCell != null) "Quitar" else if (selectedBlock == "Espacio") "Espacio" else "Colocar", fontWeight = FontWeight.Bold) }
                    ArrowControl("Derecha", Icons.Default.ArrowForward) { moveOrCursor(cells, selectedCell, cursorX, cursorY, 1, 0, canvasWidth, canvasHeight)?.let { if (selectedCell != null) selectedCell = it else { cursorX = it.first; cursorY = it.second } } }
                }
                ArrowControl("Abajo", Icons.Default.ArrowDownward) { moveOrCursor(cells, selectedCell, cursorX, cursorY, 0, 1, canvasWidth, canvasHeight)?.let { if (selectedCell != null) selectedCell = it else { cursorX = it.first; cursorY = it.second } } }
            }
            Text("Con un bloque seleccionado, las flechas lo mueven. Sin bloque, mueven la posición de inserción.", color = Muted, fontSize = 12.sp, textAlign = TextAlign.Center, modifier = Modifier.fillMaxWidth().padding(top = 4.dp))

            Text(if (asciiMode) "CARACTERES ASCII" else "BLOQUES UNICODE", color = Muted, fontSize = 12.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(top = 18.dp, bottom = 8.dp))
            Surface(color = Panel, shape = RoundedCornerShape(16.dp), modifier = Modifier.fillMaxWidth()) {
                Column(Modifier.padding(12.dp)) {
                    Text(if (asciiMode) "Caracteres de dibujo ASCII; se copian como texto simple." else "Bloques sólidos, figuras y símbolos Unicode.", color = Muted, fontSize = 12.sp)
                    Spacer(Modifier.height(8.dp))
                    blocks.chunked(6).forEach { row ->
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            row.forEach { block ->
                                val isSpace = block == "Espacio" || block == " "
                                Box(Modifier.weight(1f).padding(vertical = 3.dp).height(46.dp).border(if (selectedBlock == block) 2.dp else 1.dp, if (selectedBlock == block) Purple else Color(0xFF48495A), RoundedCornerShape(10.dp)).background(if (selectedBlock == block) Purple.copy(alpha = .18f) else Color(0xFF242635), RoundedCornerShape(10.dp)).clickable { selectedBlock = if (isSpace) "Espacio" else block; selectedCell = null; status = if (isSpace) "Espacio seleccionado: al colocarlo inserta una celda vacía." else "Bloque $block seleccionado." }.semantics { contentDescription = if (isSpace) "Seleccionar espacio" else "Seleccionar carácter $block" }, contentAlignment = Alignment.Center) {
                                    Text(if (isSpace) "␣" else block, color = White, fontSize = 20.sp, fontWeight = FontWeight.Bold)
                                }
                            }
                            repeat(6 - row.size) { Spacer(Modifier.weight(1f)) }
                        }
                    }
                }
            }

            Text("SEPARACIÓN", color = Muted, fontSize = 12.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(top = 18.dp, bottom = 4.dp))
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("Cerca", color = Muted, fontSize = 13.sp)
                Slider(value = gap.toFloat(), onValueChange = { gap = it.toInt().coerceIn(1, 4) }, valueRange = 1f..4f, steps = 2, modifier = Modifier.weight(1f).semantics { contentDescription = "Separación entre bloques, nivel $gap" })
                Text("$gap", color = White, fontWeight = FontWeight.Bold)
                Text("Lejos", color = Muted, fontSize = 13.sp)
            }

            Row(Modifier.fillMaxWidth().padding(top = 12.dp, bottom = 22.dp), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                OutlinedButton(onClick = { cells.clear(); cursorX = 0; cursorY = 0; selectedCell = null; status = "Lienzo vacío. Elige un bloque para empezar." }, modifier = Modifier.weight(1f).height(52.dp), border = BorderStroke(1.dp, Color(0xFF77788A))) {
                    Icon(Icons.Default.Delete, contentDescription = null); Spacer(Modifier.width(6.dp)); Text("Limpiar", color = White)
                }
                Button(onClick = {
                    if (cells.none { it.value.isNotEmpty() }) Toast.makeText(context, "Coloca algún bloque primero", Toast.LENGTH_SHORT).show()
                    else {
                        val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                        clipboard.setPrimaryClip(ClipData.newPlainText(if (asciiMode) "ASCII" else "Unicode", output))
                        Toast.makeText(context, "Diseño ${if (asciiMode) "ASCII" else "Unicode"} copiado. Ya puedes pegarlo en otra app.", Toast.LENGTH_LONG).show()
                    }
                }, modifier = Modifier.weight(1.25f).height(52.dp), colors = ButtonDefaults.buttonColors(containerColor = Purple, contentColor = Ink)) {
                    Icon(Icons.Default.ContentCopy, contentDescription = null); Spacer(Modifier.width(7.dp)); Text("Copiar todo", fontWeight = FontWeight.Bold)
                }
            }
        }
    }
}

private fun moveOrCursor(cells: MutableList<Cell>, selected: Pair<Int, Int>?, x: Int, y: Int, dx: Int, dy: Int, width: Int, height: Int): Pair<Int, Int>? {
    return if (selected != null) moveCell(cells, selected, dx, dy, width - 1, height - 1) else (x + dx).coerceIn(0, width - 1) to (y + dy).coerceIn(0, height - 1)
}

@Composable
private fun ArrowControl(label: String, icon: androidx.compose.ui.graphics.vector.ImageVector, onClick: () -> Unit) {
    FilledTonalButton(onClick = onClick, modifier = Modifier.size(52.dp).semantics { contentDescription = label }, shape = RoundedCornerShape(14.dp), contentPadding = PaddingValues(0.dp), colors = ButtonDefaults.filledTonalButtonColors(containerColor = Color(0xFF292B3A), contentColor = White)) {
        Icon(icon, contentDescription = null, modifier = Modifier.size(25.dp))
    }
}

private fun moveCell(cells: MutableList<Cell>, from: Pair<Int, Int>, dx: Int, dy: Int, maxX: Int = 29, maxY: Int = 19): Pair<Int, Int>? {
    val nx = (from.first + dx).coerceIn(0, maxX)
    val ny = (from.second + dy).coerceIn(0, maxY)
    if (nx == from.first && ny == from.second) return from
    val i = cells.indexOfFirst { it.x == from.first && it.y == from.second }
    if (i < 0) return null
    val occupant = cells.indexOfFirst { it.x == nx && it.y == ny }
    val old = cells[i]
    if (occupant >= 0) {
        val other = cells[occupant]
        cells[occupant] = other.copy(x = old.x, y = old.y)
    }
    cells[i] = old.copy(x = nx, y = ny)
    return nx to ny
}
